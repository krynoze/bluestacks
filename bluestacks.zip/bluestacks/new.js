function diff(){
			var givenDate = $(".date1").text();
			var datenum = parseInt(givenDate);
    		var start = new Date(datenum),
    		end   = new Date(),
    		diff  = new Date(end - start),
    		days  = diff/1000/60/60/24;
    		console.log(days);
		}

		$( document ).ready(function() {
    		$("tr td").on("click", function(){
			  		$(".popup-overlay, .popup-content").addClass("active");
			});

			$(".close, .popup-overlay").on("click", function(){
			  	$(".popup-overlay, .popup-content").removeClass("active");
			});
		});